﻿using System.Collections.Generic;

namespace VideoChat.Models
{
    public class UserCall
    {
        public List<User> Users;
    }
}